package slideshow;

public interface EventPagination {

    public void onClick(int pageClick);
}
